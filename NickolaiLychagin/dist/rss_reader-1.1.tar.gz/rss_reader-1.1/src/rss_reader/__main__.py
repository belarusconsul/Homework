from .rss_reader import run_rss_reader

if __name__ == "__main__":
    run_rss_reader()
